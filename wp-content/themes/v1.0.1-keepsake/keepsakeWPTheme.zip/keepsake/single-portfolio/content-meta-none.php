<?php 
	the_content(); 
	wp_link_pages();