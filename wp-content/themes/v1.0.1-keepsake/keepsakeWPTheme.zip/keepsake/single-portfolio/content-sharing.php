<div class="dark-wrapper">
	<div class="container inner text-center">
		<h1 class="share-button"><?php _e('Share This Work','keepsake'); ?></h1>
		<?php get_template_part('inc/content','sharing'); ?>
	</div>
</div>