jQuery(document).ready(function($){
	
	//nothing
	
});