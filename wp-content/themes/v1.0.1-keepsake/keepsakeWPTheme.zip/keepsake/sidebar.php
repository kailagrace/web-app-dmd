<aside class="col-sm-4 sidebar lp30">
	<?php dynamic_sidebar('primary'); ?>
</aside>