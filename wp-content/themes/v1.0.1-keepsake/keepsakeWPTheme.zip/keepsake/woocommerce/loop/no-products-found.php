<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div class="alert alert-info"><?php _e( 'No products were found matching your selection.', 'keepsake' ); ?></div>