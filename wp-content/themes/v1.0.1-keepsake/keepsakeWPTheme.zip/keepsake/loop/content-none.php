<p><?php _e('Sorry, no results were found, search again?','keepsake'); ?></p>

<?php get_search_form(); ?>